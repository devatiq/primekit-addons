<?php do_action( 'primekit_footer' ); ?>
<?php wp_footer(); ?>
</body>
</html> 